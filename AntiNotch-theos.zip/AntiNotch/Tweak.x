#import <UIKit/UIKit.h>
#import <objc/message.h>

#define kDomain CFSTR("com.example.antinotch")
#define kReloadNotif CFSTR("com.example.antinotch/ReloadPrefs")

@interface SpringBoard : UIApplication
- (void)_simulateHomeButtonPress;
- (id)_accessibilityFrontMostApplication;
@end
@interface UIWindow (ANPrivate)
- (void)_setSecure:(BOOL)secure;
@end

// ================= Preferences =================
static BOOL gEnabled = YES, gHaptics = YES, gLetterbox = YES, gStatusBar = YES, gDebug = YES;
static NSInteger gTheme = 0, gHapticStyle = 1;
static CGFloat gSize = 54, gAlpha = 1.0;

static id PrefValue(NSString *key, id def) {
    CFPropertyListRef v = CFPreferencesCopyAppValue((__bridge CFStringRef)key, kDomain);
    return v ? CFBridgingRelease(v) : def;
}
static void LoadPrefs(void) {
    CFPreferencesAppSynchronize(kDomain);
    gEnabled     = [PrefValue(@"enabled", @YES) boolValue];
    gHaptics     = [PrefValue(@"haptics", @YES) boolValue];
    gLetterbox   = [PrefValue(@"letterbox", @YES) boolValue];
    gStatusBar   = [PrefValue(@"statusBar", @YES) boolValue];
    gDebug       = [PrefValue(@"debug", @YES) boolValue];
    gTheme       = [PrefValue(@"theme", @0) integerValue];
    gHapticStyle = [PrefValue(@"hapticStyle", @1) integerValue];
    gSize        = [PrefValue(@"size", @54) doubleValue];
    gAlpha       = [PrefValue(@"alpha", @1.0) doubleValue];
}

// ================= Private-API helpers =================
static id Shared(NSString *cls) {
    Class c = NSClassFromString(cls);
    SEL s = NSSelectorFromString(@"sharedInstance");
    return (c && [c respondsToSelector:s]) ? ((id (*)(Class, SEL))objc_msgSend)(c, s) : nil;
}
static BOOL Call(id obj, NSString *sel) {
    SEL s = NSSelectorFromString(sel);
    if (obj && [obj respondsToSelector:s]) { ((void (*)(id, SEL))objc_msgSend)(obj, s); return YES; }
    return NO;
}
static id FrontApp(void) {
    UIApplication *a = UIApplication.sharedApplication;
    return [a respondsToSelector:@selector(_accessibilityFrontMostApplication)]
         ? [(SpringBoard *)a _accessibilityFrontMostApplication] : nil;
}

@class ANWindow;
static ANWindow *gWindow;
static void Toast(NSString *msg);

// Each strategy returns YES if the method existed and was called.
static NSArray *HomeStrategies(void) {
    return @[
        ^BOOL{ return Call(Shared(@"SBUIController"), @"clickedMenuButton"); },
        ^BOOL{ return Call(Shared(@"SBUIController"), @"handleHomeButtonSinglePressUp"); },
        ^BOOL{
            UIApplication *a = UIApplication.sharedApplication;
            if ([a respondsToSelector:@selector(_simulateHomeButtonPress)]) {
                [(SpringBoard *)a _simulateHomeButtonPress]; return YES;
            }
            return NO;
        },
        ^BOOL{ return Call(Shared(@"SBMainSwitcherViewController"), @"dismissSwitcherNoninteractively"); },
    ];
}

static void RunHomeStrategy(NSArray *list, NSUInteger i) {
    if (i >= list.count) { Toast(@"home: nothing worked"); return; }
    BOOL (^s)(void) = list[i];
    if (!s()) { RunHomeStrategy(list, i + 1); return; }
    Toast([NSString stringWithFormat:@"home: method %lu", (unsigned long)i]);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.7 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (FrontApp()) RunHomeStrategy(list, i + 1); // an app is still in front -> try next method
    });
}

static void GoHome(void) {
    if (!FrontApp()) { // already on Home Screen: scroll to first page / close folders / dismiss switcher
        BOOL a = Call(Shared(@"SBIconController"), @"handleHomeButtonTap");
        BOOL b = Call(Shared(@"SBUIController"), @"clickedMenuButton");
        Toast(a || b ? @"home screen" : @"home screen: no method");
        return;
    }
    RunHomeStrategy(HomeStrategies(), 0);
}

static void OpenSwitcher(void) {
    id sw = Shared(@"SBMainSwitcherViewController");
    SEL toggle = NSSelectorFromString(@"toggleSwitcherNoninteractivelyWithSource:");
    if (sw && [sw respondsToSelector:toggle]) {
        ((BOOL (*)(id, SEL, long long))objc_msgSend)(sw, toggle, 1);
        Toast(@"switcher");
    } else {
        GoHome();
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.15 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ GoHome(); });
    }
}

// ================= Home button view =================
@interface ANButton : UIView
@property (nonatomic, strong) UIView *inner;
@property (nonatomic, strong) UIPanGestureRecognizer *pan;
- (void)refresh;
@end

@implementation ANButton
- (instancetype)init {
    if ((self = [super initWithFrame:CGRectMake(0, 0, 54, 54)])) {
        _inner = [UIView new];
        _inner.userInteractionEnabled = NO;
        [self addSubview:_inner];

        UITapGestureRecognizer *dbl = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doubleTap)];
        dbl.numberOfTapsRequired = 2;
        [self addGestureRecognizer:dbl];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTap)];
        [tap requireGestureRecognizerToFail:dbl];
        [self addGestureRecognizer:tap];

        _pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pan:)];
        [self addGestureRecognizer:_pan];
        [self refresh];
    }
    return self;
}

- (void)refresh {
    CGPoint c = self.center;
    CGFloat s = gSize;
    self.bounds = CGRectMake(0, 0, s, s);
    self.center = c;
    self.alpha = gAlpha;
    self.layer.cornerRadius = s / 2;
    self.layer.shadowOpacity = 0;
    self.layer.borderWidth = 1.5;
    self.backgroundColor = UIColor.clearColor;
    self.pan.enabled = !gLetterbox;

    CGFloat is = s * 0.34;
    _inner.frame = CGRectMake((s - is) / 2, (s - is) / 2, is, is);
    _inner.layer.cornerRadius = is * 0.28;
    _inner.layer.borderWidth = 1.5;
    _inner.hidden = NO;
    _inner.backgroundColor = UIColor.clearColor;

    switch (gTheme) {
        default:
        case 0: { // iPhone 8 black front
            UIColor *c1 = [UIColor colorWithWhite:0.32 alpha:1];
            self.layer.borderColor = c1.CGColor; _inner.layer.borderColor = c1.CGColor;
            break;
        }
        case 1: { // iPhone 8 white front
            UIColor *c1 = [UIColor colorWithWhite:0.78 alpha:1];
            self.layer.borderColor = c1.CGColor; _inner.layer.borderColor = c1.CGColor;
            break;
        }
        case 2: { // Neon
            UIColor *neon = [UIColor colorWithRed:0.1 green:0.9 blue:1 alpha:1];
            self.layer.borderColor = neon.CGColor; _inner.layer.borderColor = neon.CGColor;
            self.layer.shadowColor = neon.CGColor; self.layer.shadowRadius = 8;
            self.layer.shadowOpacity = 0.9; self.layer.shadowOffset = CGSizeZero;
            break;
        }
        case 3: // Minimal
            self.layer.borderWidth = 0;
            self.backgroundColor = [UIColor colorWithWhite:0.25 alpha:1];
            _inner.hidden = YES;
            break;
    }
}

- (void)haptic {
    if (!gHaptics) return;
    UIImpactFeedbackStyle st = gHapticStyle == 0 ? UIImpactFeedbackStyleLight
                             : gHapticStyle == 2 ? UIImpactFeedbackStyleHeavy
                             : UIImpactFeedbackStyleMedium;
    UIImpactFeedbackGenerator *g = [[UIImpactFeedbackGenerator alloc] initWithStyle:st];
    [g prepare]; [g impactOccurred];
}
- (void)singleTap { [self haptic]; GoHome(); }
- (void)doubleTap { [self haptic]; OpenSwitcher(); }

- (void)pan:(UIPanGestureRecognizer *)g {
    UIView *sv = self.superview;
    CGPoint t = [g translationInView:sv];
    self.center = CGPointMake(self.center.x + t.x, self.center.y + t.y);
    [g setTranslation:CGPointZero inView:sv];
    if (g.state == UIGestureRecognizerStateEnded) {
        CGRect b = sv.bounds;
        CGFloat x = self.center.x / b.size.width, y = self.center.y / b.size.height;
        CFPreferencesSetAppValue(CFSTR("posX"), (__bridge CFNumberRef)@(x), kDomain);
        CFPreferencesSetAppValue(CFSTR("posY"), (__bridge CFNumberRef)@(y), kDomain);
        CFPreferencesAppSynchronize(kDomain);
    }
}
@end

// ================= Window: bars + fake status bar + button =================
@interface ANWindow : UIWindow
@property (nonatomic, strong) UIView *topBar, *bottomBar;
@property (nonatomic, strong) UILabel *timeLabel, *batLabel, *toast;
@property (nonatomic, strong) UIImageView *sigView, *wifiView, *batView;
@property (nonatomic, strong) ANButton *button;
@property (nonatomic, strong) NSTimer *timer;
- (void)setup;
- (void)refreshAll;
- (void)showToast:(NSString *)msg;
@end

@implementation ANWindow
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *v = [super hitTest:point withEvent:event];
    return (v == self || v == self.rootViewController.view) ? nil : v;
}

- (UIImageView *)symbol:(NSString *)name {
    UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration configurationWithPointSize:12 weight:UIImageSymbolWeightSemibold];
    UIImageView *iv = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:name withConfiguration:cfg]];
    iv.contentMode = UIViewContentModeScaleAspectFit;
    return iv;
}

- (void)setup {
    UIView *root = self.rootViewController.view;
    _topBar = [UIView new]; _bottomBar = [UIView new];
    [root addSubview:_topBar]; [root addSubview:_bottomBar];

    _timeLabel = [UILabel new]; _timeLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightSemibold];
    _timeLabel.textAlignment = NSTextAlignmentCenter;
    _batLabel = [UILabel new]; _batLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightSemibold];
    _batLabel.textAlignment = NSTextAlignmentRight;
    _sigView = [self symbol:@"cellularbars"];
    if (!_sigView.image) _sigView = [self symbol:@"antenna.radiowaves.left.and.right"];
    _wifiView = [self symbol:@"wifi"];
    _batView = [self symbol:@"battery.100"];
    for (UIView *v in @[_timeLabel, _batLabel, _sigView, _wifiView, _batView]) [_topBar addSubview:v];

    _button = [ANButton new];
    [root addSubview:_button];

    _toast = [UILabel new];
    _toast.font = [UIFont systemFontOfSize:11 weight:UIFontWeightMedium];
    _toast.textColor = UIColor.whiteColor;
    _toast.backgroundColor = [UIColor colorWithWhite:0.15 alpha:0.9];
    _toast.textAlignment = NSTextAlignmentCenter;
    _toast.layer.cornerRadius = 8; _toast.clipsToBounds = YES;
    _toast.alpha = 0;
    [root addSubview:_toast];

    UIDevice.currentDevice.batteryMonitoringEnabled = YES;
    __weak ANWindow *ws = self;
    _timer = [NSTimer scheduledTimerWithTimeInterval:15 repeats:YES block:^(NSTimer *t) { [ws updateStatus]; }];
    [self refreshAll];
}

- (void)updateStatus {
    _timeLabel.text = [NSDateFormatter localizedStringFromDate:NSDate.date dateStyle:NSDateFormatterNoStyle timeStyle:NSDateFormatterShortStyle];
    float lvl = UIDevice.currentDevice.batteryLevel;
    int pct = lvl < 0 ? 100 : (int)roundf(lvl * 100);
    _batLabel.text = [NSString stringWithFormat:@"%d%%", pct];
    NSString *n = pct > 87 ? @"battery.100" : pct > 62 ? @"battery.75" : pct > 37 ? @"battery.50" : pct > 12 ? @"battery.25" : @"battery.0";
    UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration configurationWithPointSize:12 weight:UIImageSymbolWeightSemibold];
    _batView.image = [UIImage systemImageNamed:n withConfiguration:cfg];
}

- (void)refreshAll {
    CGRect S = UIScreen.mainScreen.bounds;
    BOOL white = (gTheme == 1);
    UIColor *barColor = white ? UIColor.whiteColor : UIColor.blackColor;
    UIColor *fg = white ? UIColor.blackColor : UIColor.whiteColor;

    CGFloat total = MAX(S.size.height - S.size.width * 16.0 / 9.0, 0);
    CGFloat safeTop = self.safeAreaInsets.top > 0 ? self.safeAreaInsets.top : 47;
    CGFloat topH = MIN(safeTop, total * 0.5);
    CGFloat botH = total - topH;

    _topBar.hidden = _bottomBar.hidden = !gLetterbox;
    _topBar.backgroundColor = _bottomBar.backgroundColor = barColor;
    _topBar.frame = CGRectMake(0, 0, S.size.width, topH);
    _bottomBar.frame = CGRectMake(0, S.size.height - botH, S.size.width, botH);

    // iPhone 8-style status bar row: signal+wifi left, time centre, battery right
    CGFloat rowY = topH - 22;
    _topBar.clipsToBounds = YES;
    for (UIView *v in @[_timeLabel, _batLabel, _sigView, _wifiView, _batView]) {
        v.hidden = !gStatusBar;
        if ([v isKindOfClass:UILabel.class]) ((UILabel *)v).textColor = fg; else v.tintColor = fg;
    }
    _sigView.frame = CGRectMake(10, rowY, 18, 20);
    _wifiView.frame = CGRectMake(32, rowY, 18, 20);
    _timeLabel.frame = CGRectMake(S.size.width / 2 - 50, rowY, 100, 20);
    _batView.frame = CGRectMake(S.size.width - 10 - 26, rowY, 26, 20);
    _batLabel.frame = CGRectMake(S.size.width - 10 - 26 - 44, rowY, 42, 20);
    [self updateStatus];

    if (gLetterbox) {
        _button.center = CGPointMake(S.size.width / 2, S.size.height - botH / 2);
    } else {
        _button.center = CGPointMake([PrefValue(@"posX", @0.9) doubleValue] * S.size.width,
                                     [PrefValue(@"posY", @0.8) doubleValue] * S.size.height);
    }
    [_button refresh];
    [self.rootViewController.view bringSubviewToFront:_button];
    [self.rootViewController.view bringSubviewToFront:_toast];
}

- (void)showToast:(NSString *)msg {
    _toast.text = msg;
    CGSize sz = [_toast sizeThatFits:CGSizeMake(300, 24)];
    _toast.bounds = CGRectMake(0, 0, sz.width + 20, 24);
    _toast.center = CGPointMake(_button.center.x, _button.center.y - gSize / 2 - 22);
    _toast.alpha = 1;
    [UIView animateWithDuration:0.3 delay:1.5 options:0 animations:^{ self->_toast.alpha = 0; } completion:nil];
}
@end

static void Toast(NSString *msg) {
    if (!gDebug || !gWindow) return;
    dispatch_async(dispatch_get_main_queue(), ^{ [gWindow showToast:msg]; });
}

static void EnsureWindow(void) {
    if (!gEnabled) { gWindow.hidden = YES; return; }
    if (!gWindow) {
        gWindow = [[ANWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
        for (UIScene *s in UIApplication.sharedApplication.connectedScenes) {
            if ([s isKindOfClass:UIWindowScene.class]) { gWindow.windowScene = (UIWindowScene *)s; break; }
        }
        gWindow.windowLevel = UIWindowLevelAlert + 2000;
        gWindow.backgroundColor = UIColor.clearColor;
        UIViewController *vc = [UIViewController new];
        vc.view.backgroundColor = UIColor.clearColor;
        gWindow.rootViewController = vc;
        if ([gWindow respondsToSelector:@selector(_setSecure:)]) [gWindow _setSecure:YES];
        gWindow.hidden = NO;
        [gWindow setup];
    }
    gWindow.hidden = NO;
    [gWindow refreshAll];
}

static void ReloadCallback(CFNotificationCenterRef c, void *o, CFStringRef n, const void *obj, CFDictionaryRef u) {
    LoadPrefs();
    dispatch_async(dispatch_get_main_queue(), ^{ EnsureWindow(); });
}

%hook SpringBoard
- (void)applicationDidFinishLaunching:(id)application {
    %orig;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ EnsureWindow(); });
}
%end

%ctor {
    LoadPrefs();
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL,
        ReloadCallback, kReloadNotif, NULL, CFNotificationSuspensionBehaviorCoalesce);
}
