#import <UIKit/UIKit.h>
#import <objc/message.h>

#define kDomain CFSTR("com.example.antinotch")
#define kReloadNotif CFSTR("com.example.antinotch/ReloadPrefs")

@interface SpringBoard : UIApplication
- (void)_simulateHomeButtonPress;
@end
@interface UIWindow (ANPrivate)
- (void)_setSecure:(BOOL)secure;
@end

// ---------- Preferences ----------
static BOOL gEnabled = YES, gHaptics = YES;
static NSInteger gTheme = 0, gHapticStyle = 1; // 0 light,1 medium,2 heavy
static CGFloat gSize = 56, gAlpha = 1.0;

static id PrefValue(NSString *key, id def) {
    CFPropertyListRef v = CFPreferencesCopyAppValue((__bridge CFStringRef)key, kDomain);
    return v ? CFBridgingRelease(v) : def;
}
static void LoadPrefs(void) {
    CFPreferencesAppSynchronize(kDomain);
    gEnabled     = [PrefValue(@"enabled", @YES) boolValue];
    gHaptics     = [PrefValue(@"haptics", @YES) boolValue];
    gTheme       = [PrefValue(@"theme", @0) integerValue];
    gHapticStyle = [PrefValue(@"hapticStyle", @1) integerValue];
    gSize        = [PrefValue(@"size", @56) doubleValue];
    gAlpha       = [PrefValue(@"alpha", @1.0) doubleValue];
}

// ---------- Button ----------
@interface ANButton : UIView
@property (nonatomic, strong) UIVisualEffectView *blur;
@property (nonatomic, strong) UIView *inner;
- (void)refresh;
@end

@implementation ANButton

- (instancetype)init {
    if ((self = [super initWithFrame:CGRectMake(0, 0, 56, 56)])) {
        _blur = [[UIVisualEffectView alloc] initWithEffect:nil];
        _blur.userInteractionEnabled = NO;
        _blur.clipsToBounds = YES;
        [self addSubview:_blur];

        _inner = [UIView new];
        _inner.userInteractionEnabled = NO;
        [self addSubview:_inner];

        UITapGestureRecognizer *dbl = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doubleTap)];
        dbl.numberOfTapsRequired = 2;
        [self addGestureRecognizer:dbl];

        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTap)];
        [tap requireGestureRecognizerToFail:dbl];
        [self addGestureRecognizer:tap];

        [self addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pan:)]];
        [self refresh];
    }
    return self;
}

- (void)refresh {
    CGPoint c = self.center;
    CGFloat s = gSize;
    self.bounds = CGRectMake(0, 0, s, s);
    self.center = c;
    self.alpha = gAlpha;
    self.layer.cornerRadius = s / 2;
    self.layer.borderWidth = 0;
    self.layer.shadowOpacity = 0;
    self.backgroundColor = UIColor.clearColor;
    _blur.frame = self.bounds;
    _blur.layer.cornerRadius = s / 2;

    CGFloat is = s * 0.38;
    _inner.frame = CGRectMake((s - is) / 2, (s - is) / 2, is, is);
    _inner.layer.cornerRadius = is / 2;
    _inner.layer.borderWidth = 2;
    _inner.hidden = NO;
    _inner.backgroundColor = UIColor.clearColor;

    switch (gTheme) {
        default:
        case 0: // Classic (dark glass)
            _blur.effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
            self.layer.borderWidth = 2;
            self.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.6].CGColor;
            _inner.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.7].CGColor;
            break;
        case 1: // Light glass
            _blur.effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleExtraLight];
            self.layer.borderWidth = 2;
            self.layer.borderColor = [UIColor colorWithWhite:0 alpha:0.35].CGColor;
            _inner.layer.borderColor = [UIColor colorWithWhite:0 alpha:0.5].CGColor;
            break;
        case 2: // Solid dark
            _blur.effect = nil;
            self.backgroundColor = [UIColor colorWithWhite:0.05 alpha:0.92];
            self.layer.borderWidth = 2;
            self.layer.borderColor = [UIColor colorWithWhite:0.45 alpha:1].CGColor;
            _inner.layer.borderColor = [UIColor colorWithWhite:0.6 alpha:1].CGColor;
            break;
        case 3: { // Neon
            _blur.effect = nil;
            UIColor *neon = [UIColor colorWithRed:0.1 green:0.9 blue:1 alpha:1];
            self.backgroundColor = [UIColor colorWithWhite:0 alpha:0.35];
            self.layer.borderWidth = 2;
            self.layer.borderColor = neon.CGColor;
            self.layer.shadowColor = neon.CGColor;
            self.layer.shadowRadius = 8;
            self.layer.shadowOpacity = 0.9;
            self.layer.shadowOffset = CGSizeZero;
            _inner.layer.borderColor = neon.CGColor;
            break;
        }
        case 4: // Minimal
            _blur.effect = nil;
            self.backgroundColor = [UIColor colorWithWhite:1 alpha:0.25];
            _inner.hidden = YES;
            break;
    }
}

- (void)haptic {
    if (!gHaptics) return;
    UIImpactFeedbackStyle st = gHapticStyle == 0 ? UIImpactFeedbackStyleLight
                             : gHapticStyle == 2 ? UIImpactFeedbackStyleHeavy
                             : UIImpactFeedbackStyleMedium;
    UIImpactFeedbackGenerator *g = [[UIImpactFeedbackGenerator alloc] initWithStyle:st];
    [g prepare];
    [g impactOccurred];
}

- (void)pressHome {
    UIApplication *app = UIApplication.sharedApplication;
    if ([app respondsToSelector:@selector(_simulateHomeButtonPress)])
        [(SpringBoard *)app _simulateHomeButtonPress];
}

- (void)singleTap {
    [self haptic];
    [self pressHome];
}

- (void)doubleTap {
    [self haptic];
    // Try opening the app switcher directly, otherwise fall back to two home presses.
    id sw = [NSClassFromString(@"SBMainSwitcherViewController") performSelector:NSSelectorFromString(@"sharedInstance")];
    SEL toggle = NSSelectorFromString(@"toggleSwitcherNoninteractivelyWithSource:");
    if (sw && [sw respondsToSelector:toggle]) {
        ((BOOL (*)(id, SEL, long long))objc_msgSend)(sw, toggle, 1);
    } else {
        [self pressHome];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.12 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{ [self pressHome]; });
    }
}

- (void)pan:(UIPanGestureRecognizer *)g {
    UIView *sv = self.superview;
    CGPoint t = [g translationInView:sv];
    self.center = CGPointMake(self.center.x + t.x, self.center.y + t.y);
    [g setTranslation:CGPointZero inView:sv];

    if (g.state == UIGestureRecognizerStateEnded || g.state == UIGestureRecognizerStateCancelled) {
        CGRect b = sv.bounds;
        CGFloat m = gSize / 2 + 8;
        CGFloat x = self.center.x < b.size.width / 2 ? m : b.size.width - m; // snap to nearest side
        CGFloat y = MIN(MAX(self.center.y, m + 50), b.size.height - m - 30);
        [UIView animateWithDuration:0.25 delay:0 usingSpringWithDamping:0.8 initialSpringVelocity:0 options:0 animations:^{
            self.center = CGPointMake(x, y);
        } completion:nil];
        CFPreferencesSetAppValue(CFSTR("posX"), (__bridge CFNumberRef)@(x / b.size.width), kDomain);
        CFPreferencesSetAppValue(CFSTR("posY"), (__bridge CFNumberRef)@(y / b.size.height), kDomain);
        CFPreferencesAppSynchronize(kDomain);
    }
}
@end

// ---------- Pass-through window ----------
@interface ANWindow : UIWindow
@property (nonatomic, strong) ANButton *button;
@end

@implementation ANWindow
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *v = [super hitTest:point withEvent:event];
    return (v == self || v == self.rootViewController.view) ? nil : v;
}
@end

static ANWindow *gWindow;

static void EnsureWindow(void) {
    if (!gEnabled) { gWindow.hidden = YES; return; }
    if (!gWindow) {
        gWindow = [[ANWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
        for (UIScene *s in UIApplication.sharedApplication.connectedScenes) {
            if ([s isKindOfClass:UIWindowScene.class]) { gWindow.windowScene = (UIWindowScene *)s; break; }
        }
        gWindow.windowLevel = UIWindowLevelAlert + 2000;
        gWindow.backgroundColor = UIColor.clearColor;
        UIViewController *vc = [UIViewController new];
        vc.view.backgroundColor = UIColor.clearColor;
        gWindow.rootViewController = vc;
        if ([gWindow respondsToSelector:@selector(_setSecure:)]) [gWindow _setSecure:YES];

        ANButton *btn = [ANButton new];
        CGRect b = UIScreen.mainScreen.bounds;
        CGFloat px = [PrefValue(@"posX", @0.9) doubleValue];
        CGFloat py = [PrefValue(@"posY", @0.8) doubleValue];
        [vc.view addSubview:btn];
        btn.center = CGPointMake(px * b.size.width, py * b.size.height);
        gWindow.button = btn;
    }
    [gWindow.button refresh];
    gWindow.hidden = NO;
}

static void ReloadCallback(CFNotificationCenterRef c, void *o, CFStringRef n, const void *obj, CFDictionaryRef u) {
    LoadPrefs();
    dispatch_async(dispatch_get_main_queue(), ^{ EnsureWindow(); });
}

%hook SpringBoard
- (void)applicationDidFinishLaunching:(id)application {
    %orig;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{ EnsureWindow(); });
}
%end

%ctor {
    LoadPrefs();
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL,
        ReloadCallback, kReloadNotif, NULL, CFNotificationSuspensionBehaviorCoalesce);
}
