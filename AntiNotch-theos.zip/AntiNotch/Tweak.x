#import <UIKit/UIKit.h>
#import <objc/message.h>
#import <dlfcn.h>
#import <notify.h>
#include <unistd.h>
#include <mach/mach_time.h>

#define kDomain CFSTR("com.example.antinotch")
#define kReloadNotif CFSTR("com.example.antinotch/ReloadPrefs")

@interface SpringBoard : UIApplication
- (void)_simulateHomeButtonPress;
- (id)_accessibilityFrontMostApplication;
@end
@interface UIWindow (ANPrivate)
- (void)_setSecure:(BOOL)secure;
@end

// ================= Preferences =================
static BOOL gEmulateHW = NO, gScreen169 = NO;
static CGFloat gTopOffset = 47;
static void PublishState(void);
static BOOL gEnabled = YES, gHaptics = YES, gLetterbox = YES, gStatusBar = YES, gDebug = YES;
static NSInteger gTheme = 0, gHapticStyle = 1;
static CGFloat gSize = 54, gAlpha = 1.0;

static id PrefValue(NSString *key, id def) {
    CFPropertyListRef v = CFPreferencesCopyAppValue((__bridge CFStringRef)key, kDomain);
    return v ? CFBridgingRelease(v) : def;
}
static void LoadPrefs(void) {
    CFPreferencesAppSynchronize(kDomain);
    gEnabled     = [PrefValue(@"enabled", @YES) boolValue];
    gHaptics     = [PrefValue(@"haptics", @YES) boolValue];
    gLetterbox   = [PrefValue(@"letterbox", @NO) boolValue];
    gStatusBar   = [PrefValue(@"statusBar", @NO) boolValue];
    gDebug       = [PrefValue(@"debug", @YES) boolValue];
    gEmulateHW   = [PrefValue(@"emulateHW", @NO) boolValue];
    gTheme       = [PrefValue(@"theme", @0) integerValue];
    gHapticStyle = [PrefValue(@"hapticStyle", @1) integerValue];
    gSize        = [PrefValue(@"size", @54) doubleValue];
    gAlpha       = [PrefValue(@"alpha", @1.0) doubleValue];
    gScreen169   = [PrefValue(@"screen169", @NO) boolValue];
    gTopOffset   = [PrefValue(@"topBar", @47) doubleValue];
    PublishState();
}

// ================= Private-API helpers =================
static id Shared(NSString *cls) {
    Class c = NSClassFromString(cls);
    SEL s = NSSelectorFromString(@"sharedInstance");
    return (c && [c respondsToSelector:s]) ? ((id (*)(Class, SEL))objc_msgSend)(c, s) : nil;
}
static BOOL Call(id obj, NSString *sel) {
    SEL s = NSSelectorFromString(sel);
    if (obj && [obj respondsToSelector:s]) { ((void (*)(id, SEL))objc_msgSend)(obj, s); return YES; }
    return NO;
}
static id FrontApp(void) {
    UIApplication *a = UIApplication.sharedApplication;
    return [a respondsToSelector:@selector(_accessibilityFrontMostApplication)]
         ? [(SpringBoard *)a _accessibilityFrontMostApplication] : nil;
}

@class ANWindow;
static ANWindow *gWindow;
static void Toast(NSString *msg);


// ---- Find a live instance by walking object ivars (the Home-button action objects have no singleton) ----
static id FindInstance(Class target, NSArray *roots) {
    if (!target) return nil;
    NSHashTable *seen = [NSHashTable hashTableWithOptions:NSPointerFunctionsOpaquePersonality | NSPointerFunctionsOpaqueMemory];
    NSMutableArray *q = [NSMutableArray array], *depths = [NSMutableArray array];
    for (id r in roots) if (r) { [q addObject:r]; [depths addObject:@0]; [seen addObject:r]; }
    NSUInteger head = 0;
    while (head < q.count && head < 4000) {
        id o = q[head]; NSInteger dp = [depths[head] integerValue]; head++;
        if ([o isKindOfClass:target]) return o;
        if (dp >= 5) continue;
        if ([o isKindOfClass:UIView.class] || [o isKindOfClass:CALayer.class] || [o isKindOfClass:NSString.class] ||
            [o isKindOfClass:NSNumber.class] || [o isKindOfClass:UIImage.class] || [o isKindOfClass:NSData.class]) continue;
        NSArray *kids = nil;
        if ([o isKindOfClass:NSArray.class]) kids = o;
        else if ([o isKindOfClass:NSSet.class]) kids = [o allObjects];
        else if ([o isKindOfClass:NSDictionary.class]) kids = [o allValues];
        if (kids) {
            NSUInteger c = 0;
            for (id k in kids) { if (c++ > 64) break; if (![seen containsObject:k]) { [seen addObject:k]; [q addObject:k]; [depths addObject:@(dp + 1)]; } }
            continue;
        }
        for (Class k = object_getClass(o); k && k != NSObject.class; k = class_getSuperclass(k)) {
            unsigned int n = 0;
            Ivar *iv = class_copyIvarList(k, &n);
            for (unsigned int i = 0; i < n; i++) {
                const char *t = ivar_getTypeEncoding(iv[i]);
                if (!t || t[0] != '@' || t[1] == '?') continue;
                id v = object_getIvar(o, iv[i]);
                if (!v || [seen containsObject:v]) continue;
                [seen addObject:v]; [q addObject:v]; [depths addObject:@(dp + 1)];
            }
            free(iv);
        }
    }
    return nil;
}

static id gActions;
static BOOL ActionsCall(NSString *sel) {
    if (!gActions) {
        NSMutableArray *roots = [NSMutableArray array];
        for (id r in @[ Shared(@"SBUIController") ?: NSNull.null, UIApplication.sharedApplication,
                        Shared(@"SBMainWorkspace") ?: NSNull.null ]) if (r != NSNull.null) [roots addObject:r];
        gActions = FindInstance(NSClassFromString(@"SBHomeHardwareButtonActions"), roots);
    }
    return Call(gActions, sel);
}

// ---- Synthetic hardware Home key (HID usage page 0x0C, usage 0x40) ----
static BOOL SendHomeHID(void) {
    void *io = dlopen("/System/Library/Frameworks/IOKit.framework/IOKit", RTLD_NOW);
    if (!io) return NO;
    void *(*Create)(CFAllocatorRef, uint64_t, uint32_t, uint32_t, Boolean, uint32_t) = dlsym(io, "IOHIDEventCreateKeyboardEvent");
    void (*SetSender)(void *, uint64_t) = dlsym(io, "IOHIDEventSetSenderID");
    void *(*ClientCreate)(CFAllocatorRef) = dlsym(io, "IOHIDEventSystemClientCreate");
    void (*Dispatch)(void *, void *) = dlsym(io, "IOHIDEventSystemClientDispatchEvent");
    if (!Create || !SetSender || !ClientCreate || !Dispatch) return NO;
    static void *client;
    if (!client) client = ClientCreate(kCFAllocatorDefault);
    if (!client) return NO;
    for (int down = 1; down >= 0; down--) {
        void *ev = Create(kCFAllocatorDefault, mach_absolute_time(), 0x0C, 0x40, down, 0);
        if (!ev) return NO;
        SetSender(ev, 0x8000000817319372ULL);
        Dispatch(client, ev);
        CFRelease(ev);
        if (down) usleep(60000);
    }
    return YES;
}

// ---- Make the system believe this phone has a physical Home button (experimental, SpringBoard only) ----
static NSMutableString *gSpoofLog;
static void ApplyHomeSpoof(void) {
    if (!gSpoofLog) gSpoofLog = [NSMutableString string];
    NSDictionary *vals = @{ @"_hasHomeButton": @1, @"wantsHomeGesture": @0, @"isHomeGestureEnabled": @0 };
    unsigned int n = 0;
    Class *cl = objc_copyClassList(&n);
    for (unsigned int i = 0; i < n; i++) {
        unsigned int mc = 0;
        Method *ms = class_copyMethodList(cl[i], &mc);
        for (unsigned int j = 0; j < mc; j++) {
            NSString *name = NSStringFromSelector(method_getName(ms[j]));
            NSNumber *val = vals[name];
            if (!val || method_getNumberOfArguments(ms[j]) != 2) continue;
            char *rt = method_copyReturnType(ms[j]);
            BOOL ok = rt && (rt[0] == 'c' || rt[0] == 'B' || rt[0] == 'i' || rt[0] == 'q' || rt[0] == 'l');
            free(rt);
            if (!ok) continue;
            NSInteger v = val.integerValue;
            method_setImplementation(ms[j], imp_implementationWithBlock(^NSInteger(id _s) { return v; }));
            [gSpoofLog appendFormat:@"spoofed -[%@ %@] -> %ld\n", NSStringFromClass(cl[i]), name, (long)v];
        }
        free(ms);
    }
    free(cl);
}

// Each strategy returns YES if the method existed and was called.
static NSArray *HomeStrategies(void) {
    return @[
        ^BOOL{ return ActionsCall(@"performSinglePressActions"); },
        ^BOOL{ return SendHomeHID(); },
        ^BOOL{ return Call(Shared(@"SBUIController"), @"clickedMenuButton"); },
        ^BOOL{ return Call(Shared(@"SBUIController"), @"handleHomeButtonSinglePressUp"); },
        ^BOOL{
            UIApplication *a = UIApplication.sharedApplication;
            if ([a respondsToSelector:@selector(_simulateHomeButtonPress)]) {
                [(SpringBoard *)a _simulateHomeButtonPress]; return YES;
            }
            return NO;
        },
        ^BOOL{ return Call(Shared(@"SBMainSwitcherViewController"), @"dismissSwitcherNoninteractively"); },
    ];
}

static void RunHomeStrategy(NSArray *list, NSUInteger i) {
    if (i >= list.count) { Toast(@"home: nothing worked"); return; }
    BOOL (^s)(void) = list[i];
    if (!s()) { RunHomeStrategy(list, i + 1); return; }
    Toast([NSString stringWithFormat:@"home: method %lu", (unsigned long)i]);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.7 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (FrontApp()) RunHomeStrategy(list, i + 1); // an app is still in front -> try next method
    });
}

static void GoHome(void) {
    if (!FrontApp()) { // already on Home Screen: scroll to first page / close folders / dismiss switcher
        BOOL a = ActionsCall(@"performSinglePressActions") || Call(Shared(@"SBIconController"), @"handleHomeButtonTap");
        BOOL b = Call(Shared(@"SBUIController"), @"clickedMenuButton");
        Toast(a || b ? @"home screen" : @"home screen: no method");
        return;
    }
    RunHomeStrategy(HomeStrategies(), 0);
}

// Find and call whatever "toggle switcher" method this iOS version has, adapting to its arguments.
static NSString *ToggleSwitcherDynamic(void) {
    id sw = Shared(@"SBMainSwitcherViewController");
    if (!sw) return nil;
    NSString *best = nil; int bestScore = 0;
    for (Class k = object_getClass(sw); k && k != NSObject.class; k = class_getSuperclass(k)) {
        unsigned int n = 0;
        Method *ms = class_copyMethodList(k, &n);
        for (unsigned int i = 0; i < n; i++) {
            NSString *name = NSStringFromSelector(method_getName(ms[i]));
            NSString *low = name.lowercaseString;
            if (![low hasPrefix:@"toggle"] || ![low containsString:@"switcher"]) continue;
            // only accept simple argument types we know how to fill
            BOOL ok = YES;
            for (unsigned int a = 2; a < method_getNumberOfArguments(ms[i]); a++) {
                char *t = method_copyArgumentType(ms[i], a);
                char c = t ? t[0] : 0;
                if (!(c == 'q' || c == 'Q' || c == 'l' || c == 'i' || c == 'B' || c == 'c' || (c == '@' && t[1] == '?'))) ok = NO;
                free(t);
            }
            if (!ok || method_getNumberOfArguments(ms[i]) > 5) continue;
            int score = 1 + ([low containsString:@"noninteractively"] ? 2 : 0) + ([low containsString:@"source"] ? 1 : 0);
            if (score > bestScore) { bestScore = score; best = name; }
        }
        free(ms);
    }
    if (!best) return nil;
    SEL sel = NSSelectorFromString(best);
    NSMethodSignature *sig = [sw methodSignatureForSelector:sel];
    if (!sig) return nil;
    NSInvocation *inv = [NSInvocation invocationWithMethodSignature:sig];
    inv.target = sw; inv.selector = sel;
    for (NSUInteger a = 2; a < sig.numberOfArguments; a++) {
        const char *t = [sig getArgumentTypeAtIndex:a];
        if (t[0] == 'B' || t[0] == 'c') { BOOL y = YES; [inv setArgument:&y atIndex:a]; }
        else if (t[0] == '@') { void *nilBlock = NULL; [inv setArgument:&nilBlock atIndex:a]; }
        else { long long v = 1; [inv setArgument:&v atIndex:a]; }
    }
    [inv invoke];
    return best;
}

static void OpenSwitcher(void) {
    if (ActionsCall(@"performDoublePressActions")) { Toast(@"double press: actions"); return; }
    NSString *used = ToggleSwitcherDynamic();
    if (used) { Toast([@"switcher: " stringByAppendingString:used]); return; }
    // last resort: two Home key events in quick succession
    Toast(@"switcher: double HID");
    SendHomeHID();
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.12 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ SendHomeHID(); });
}

// ================= 16:9 screen mode =================
// SpringBoard publishes the setting through notifyd state; app processes read it once at launch
// (relaunch an app after changing the setting). Kill switch: create /var/mobile/.antinotch_off
#define kStateKey "com.example.antinotch.state"

static void PublishState(void) {
    static int tok; static BOOL have;
    if (!have) { if (notify_register_check(kStateKey, &tok) != NOTIFY_STATUS_OK) return; have = YES; }
    int top = (int)MAX(0, MIN(255, gTopOffset));
    uint64_t st = ((gEnabled && gScreen169) ? 1 : 0) | ((uint64_t)top << 8);
    notify_set_state(tok, st);
    notify_post(kStateKey);
}

static CGSize gPhys;
static CGFloat gAppTop = 47;

static BOOL IsFullSize(CGSize z) {
    return (fabs(z.width - gPhys.width) < 1.5 && fabs(z.height - gPhys.height) < 1.5) ||
           (fabs(z.width - gPhys.height) < 1.5 && fabs(z.height - gPhys.width) < 1.5);
}
static CGRect FitRect(CGRect r) { // 16:9 rect inside a full-screen rect
    if (r.size.width <= r.size.height) {
        CGFloat h = floor(r.size.width * 16.0 / 9.0);
        return CGRectMake(r.origin.x, r.origin.y + gAppTop, r.size.width, h);
    }
    CGFloat w = floor(r.size.height * 16.0 / 9.0);
    return CGRectMake(r.origin.x + (r.size.width - w) / 2, r.origin.y, w, r.size.height);
}
static IMP SwapOn(Class c, SEL s, IMP n) {
    Method m = class_getInstanceMethod(c, s);
    if (!m) return NULL;
    IMP orig = method_getImplementation(m);
    if (!class_addMethod(c, s, n, method_getTypeEncoding(m))) method_setImplementation(class_getInstanceMethod(c, s), n);
    return orig;
}

static CGRect (*orig_bounds)(id, SEL);
static CGRect new_bounds(id self, SEL _cmd) {
    CGRect r = orig_bounds(self, _cmd);
    if (IsFullSize(r.size)) r.size = FitRect(r).size;
    return r;
}
static CGRect (*orig_refBounds)(id, SEL);
static CGRect new_refBounds(id self, SEL _cmd) {
    CGRect r = orig_refBounds(self, _cmd);
    if (IsFullSize(r.size)) r.size = FitRect(r).size;
    return r;
}

static BOOL EligibleWindow(UIWindow *w) { return w.windowLevel <= 5.0; } // normal app windows only (not keyboard/alerts)

static void (*orig_setFrame)(id, SEL, CGRect);
static void new_setFrame(id self, SEL _cmd, CGRect r) {
    if ([self isKindOfClass:UIWindow.class] && EligibleWindow(self) && IsFullSize(r.size)) r = FitRect(r);
    orig_setFrame(self, _cmd, r);
}
static void AdjustWindow(UIWindow *w) {
    if (EligibleWindow(w) && IsFullSize(w.frame.size)) w.frame = w.frame; // goes through new_setFrame
}
static void (*orig_layout)(id, SEL);
static void new_layout(id self, SEL _cmd) { orig_layout(self, _cmd); AdjustWindow(self); }
static void (*orig_mkv)(id, SEL);
static void new_mkv(id self, SEL _cmd) { AdjustWindow(self); orig_mkv(self, _cmd); AdjustWindow(self); }

static void InstallAppScreenHooks(void) {
    UIScreen *ms = UIScreen.mainScreen;
    CGSize nb = ms.nativeBounds.size; CGFloat sc = ms.nativeScale ?: 1;
    gPhys = CGSizeMake(MIN(nb.width, nb.height) / sc, MAX(nb.width, nb.height) / sc);
    orig_bounds    = (void *)SwapOn(UIScreen.class, @selector(bounds), (IMP)new_bounds);
    orig_refBounds = (void *)SwapOn(UIScreen.class, NSSelectorFromString(@"_referenceBounds"), (IMP)new_refBounds);
    orig_setFrame  = (void *)SwapOn(UIWindow.class, @selector(setFrame:), (IMP)new_setFrame);
    orig_layout    = (void *)SwapOn(UIWindow.class, @selector(layoutSubviews), (IMP)new_layout);
    orig_mkv       = (void *)SwapOn(UIWindow.class, @selector(makeKeyAndVisible), (IMP)new_mkv);
}

%group SBGroup
%hook SpringBoard
- (void)applicationDidFinishLaunching:(id)application {
    %orig;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ EnsureWindow(); });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(8.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ DumpRuntime(); });
}
%end
%end

%ctor {
    if (access("/var/mobile/.antinotch_off", F_OK) == 0) return; // kill switch
    NSString *proc = NSProcessInfo.processInfo.processName;
    if ([proc isEqualToString:@"SpringBoard"]) {
        LoadPrefs();
        if (gEmulateHW) ApplyHomeSpoof();
        CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL,
            ReloadCallback, kReloadNotif, NULL, CFNotificationSuspensionBehaviorCoalesce);
        %init(SBGroup);
    } else {
        // third-party / system app process: only act if 16:9 mode is on and this is a real app
        NSString *type = NSBundle.mainBundle.infoDictionary[@"CFBundlePackageType"];
        if (![type isEqualToString:@"APPL"]) return;
        int tok = 0; uint64_t st = 0;
        if (notify_register_check(kStateKey, &tok) == NOTIFY_STATUS_OK) notify_get_state(tok, &st);
        if (st & 1) {
            gAppTop = (CGFloat)((st >> 8) & 0xFF);
            InstallAppScreenHooks();
        }
    }
}
