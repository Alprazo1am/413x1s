#import <Preferences/PSListController.h>

@interface ANPRootListController : PSListController
@end

@implementation ANPRootListController
- (NSArray *)specifiers {
    if (!_specifiers) _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
    return _specifiers;
}
@end
